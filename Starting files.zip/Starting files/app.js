const express=require("express");
const bodyParser=require("body-parser");
const app=express();
app.set("view engine",'ejs');
app.use(bodyParser.urlencoded({extended:true}));
// Connect Mongodb with mongoose
const mongoose=require('mongoose');
const url="mongodb://127.0.0.1:27017/UserDB";
mongoose.connect(url,{useNewUrlParser:true});
// check if we are Connected
const db=mongoose.connection;
db.once('open',function(){
  console.log("Database Connected");
});
app.get("/login",function(req,res){
  res.render("login");
});
app.get("/register",function(req,res){
   res.render("register");
});
//  home page
app.get("/",function(req,res){
    res.render("home");

});






app.listen(3000,function(){
    console.log("Server is Running on 3000");
});

